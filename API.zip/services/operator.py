# services/operator.py

"""
Оператор пайплайна.
Очищает, парсит и маршрутизирует JSON-задачи от YandexGPT.
"""

import json
from typing import Dict, Any

from aiogram.types import Message


class Operator:
    """
    Класс для обработки пайплайна задач от ИИ.
    """

    def __init__(self, executors: Dict[str, Any]):
        """
        Инициализирует оператор с реестром исполнителей.

        Args:
            executors: Словарь, где ключ — тип задачи (например, "text"),
                       значение — экземпляр класса-исполнителя.
        """
        self.executors = executors

    def _clean_ai_response(self, raw_string: str) -> str:
        """
        Извлекает из сырой строки часть, содержащую JSON-массив.

        Ищет первую '[' и последнюю ']' и возвращает всё, что между ними
        (включая сами скобки). Если найти не удалось — возвращает "[]".

        Args:
            raw_string: Сырая строка ответа от ИИ

        Returns:
            Очищенная строка с JSON-массивом
        """
        try:
            start = raw_string.find('[')
            end = raw_string.rfind(']')
            if start != -1 and end > start:
                return raw_string[start:end + 1]
        except Exception:
            pass
        return "[]"

    async def process(self, message: Message, raw_json_string: str):
        """
        Основной метод обработки пайплайна.

        Args:
            message: Объект сообщения Telegram
            raw_json_string: Сырая строка от YandexGPT с JSON-массивом
        """
        # 1. Очищаем строку от мусора
        cleaned = self._clean_ai_response(raw_json_string)

        # 2. Парсим JSON в список словарей
        try:
            tasks = json.loads(cleaned)
        except json.JSONDecodeError:
            await message.answer("❌ Ошибка: ответ от ИИ не является валидным JSON.")
            return

        # 3. Проверяем, что получили список
        if not isinstance(tasks, list):
            await message.answer("❌ Ошибка: ожидался JSON-массив, получен объект.")
            return

        # 4. Маршрутизация задач
        for task in tasks:
            # Проверяем, что задача — это словарь
            if not isinstance(task, dict):
                await message.answer(f"⚠️ Неизвестный формат задачи: {task}")
                continue

            # Определяем тип задачи по ключу
            if "text" in task:
                executor = self.executors.get("text")
                if executor:
                    await executor.execute(message, task["text"])
                else:
                    await message.answer("⚠️ Исполнитель для текста не зарегистрирован.")

            elif "image" in task:
                executor = self.executors.get("image")
                if executor:
                    await executor.execute(message, task["image"])
                else:
                    await message.answer("⚠️ Исполнитель для изображений не зарегистрирован.")

            else:
                # Если в задаче неизвестный ключ
                await message.answer(f"⚠️ Неизвестный тип задачи: {list(task.keys())}")