# services/executors.py

"""
Исполнители задач для пайплайна.
Каждый исполнитель имеет метод execute() с единым интерфейсом.
"""

from aiogram.types import Message, BufferedInputFile

from services.fusionbrain_api import generate


class TextExecutor:
    """Исполнитель для текстовых задач."""

    async def execute(self, message: Message, text: str):
        """
        Отправляет текст пользователю.

        Args:
            message: Объект сообщения Telegram
            text: Текст для отправки
        """
        await message.answer(text)


class ImageExecutor:
    """Исполнитель для задач генерации изображений."""

    async def execute(self, message: Message, prompt: str):
        """
        Генерирует изображение по промпту и отправляет пользователю.

        Args:
            message: Объект сообщения Telegram
            prompt: Промпт для генерации
        """
        await message.answer(f"🎨 Генерирую картинку по запросу: {prompt}")

        try:
            # Генерируем изображение
            image_bytes = generate(prompt)

            # Отправляем пользователю
            image_file = BufferedInputFile(image_bytes, filename="generated.png")
            await message.answer_photo(
                image_file,
                caption="🖼️ Сгенерированное изображение"
            )

        except Exception as e:
            await message.answer(f"❌ Ошибка генерации: {str(e)}")