# main.py

"""
Точка входа. Инициализация и запуск бота.
"""

import asyncio

from config import RATE_LIMIT_INTERVAL_SECONDS
from core import bot, dp
from database import load_db
from handlers.commands import router as commands_router
from handlers.multimodal import router as multimodal_router
from logger import log_info
from middlewares.ratelimit import RateLimitMiddleware


async def main():
    """Собирает всё вместе и запускает."""

    # 1. Загружаем базу данных
    load_db()
    log_info("База данных загружена")

    # 2. Подключаем защиту от спама
    dp.message.middleware(RateLimitMiddleware(min_interval=RATE_LIMIT_INTERVAL_SECONDS))
    log_info("Middleware защиты от спама подключён")

    # 3. Подключаем обработчики
    dp.include_router(commands_router)
    dp.include_router(multimodal_router)
    log_info("Хендлеры зарегистрированы")

    # 4. Запускаем бота
    log_info("Бот запущен")
    print("🤖 Бот запущен! Данные сохраняются в БД.")
    print("Нажми Ctrl+C для остановки.")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())