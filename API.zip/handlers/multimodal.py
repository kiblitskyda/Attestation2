# handlers/multimodal.py

"""
Обработчик мультимодальных запросов.
Принимает текстовые сообщения и запускает пайплайн (текст + картинки).
"""

from aiogram import Router, F
from aiogram.types import Message

from database import check_rate_limit
from logger import log_info, log_warning
from services.dialog_service import get_multimodal_response
from services.executors import TextExecutor, ImageExecutor
from services.operator import Operator

router = Router()

@router.message(~F.text.startswith("/"))
async def handle_multimodal(message: Message):
    user_id = message.from_user.id
    user_input = message.text

    # 1. Проверяем лимит запросов
    if not check_rate_limit(user_id):
        await message.answer("⏳ Вы превысили лимит запросов. Попробуйте позже.")
        log_warning(f"Пользователь {user_id} превысил лимит запросов")
        return

    # 2. Показываем статус "печатает..."
    await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")

    # 3. Получаем JSON от YandexGPT
    log_info(f"Пользователь {user_id}: {user_input[:100]}...")
    try:
        raw_json = await get_multimodal_response(user_id, user_input)
    except Exception as e:
        await message.answer(f"❌ Ошибка при запросе к YandexGPT: {str(e)}")
        log_warning(f"Ошибка YandexGPT для {user_id}: {e}")
        return

    # 4. Запускаем оператор
    operator = Operator({
        "text": TextExecutor(),
        "image": ImageExecutor()
    })

    try:
        await operator.process(message, raw_json)
        log_info(f"Пайплайн для {user_id} успешно выполнен")
    except Exception as e:
        await message.answer(f"❌ Ошибка при обработке пайплайна: {str(e)}")
        log_warning(f"Ошибка пайплайна для {user_id}: {e}")